using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Threading;
using System.Threading.Tasks;
using System.Security.Principal;
using Eternals;
using Eternals.Utils;
using WebSocketSharp;

namespace Eternal;

internal class Program
{
	private static byte[] array;

	private static byte[] array2;

	private static byte[] array3;

	public static List<(string, string, string, string)> BotList = new List<(string, string, string, string)>();

	public static List<string> BotExport = new List<string>();

	public static string[] Bots = new string[0];

	public static Session Session = new Session();

	public static string[] Tickets = new string[0];

	private static Random RandomString = new Random();

	public static List<object> MS = new List<object>();

	public static string VER = "";

	public static string HWID;

	public static string Path = "";

	public static string Ticket = "";

	public static string GetServer = "";

	public static string BotUsername = "";

	public static string GetUsername = "";

	public static string GetPassword = "";

	public static string WebSocketPath = "";

	public static string GetNebulaAccess = "";

	public static string GetNebulaProfile = "";

	public static int MovieId = -100;

	public static int MovieIdSecured = -100;

	public static int ActorId = -100;

	public static int GetMyRole = -100;

	public static int GetMyRoleSecured = -100;

	public static int IsAutomated = -100;

	public static int AutomatedStep = 0;

	public static int sessionIdUsed = 0;

	public static int MovieViews = -100;

	public static int StarcoinsEarned = -100;

	public static int AutographsGiven = -100;

	public static int BotsLogged = -100;

	private static WebClient webClient = new WebClient
	{
		Proxy = null
	};

	public static string GenerateRandomName(int Length)
	{
		return new string((from s in Enumerable.Repeat("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789", Length)
			select s[RandomString.Next(s.Length)]).ToArray());
	}

	private static void Main(string[] args)
	{
		Console.Title = "⛤LeaF";
		string text = webClient.DownloadString("https://pastebin.com/raw/f84BMECB");
		if (text == "0")
		{
			Console.ForegroundColor = ConsoleColor.DarkRed;
			Console.WriteLine("NEW VERSION FOUNDED! CHECK OUR DISCORD SERVER");
			Console.WriteLine("CLICK ENTER TO EXIT");
			Console.ReadLine();
			Environment.Exit(0);
		}
		string text2 = webClient.DownloadString("https://pastebin.com/raw/UrzAmysn");
		HWID = WindowsIdentity.GetCurrent().User.Value;
		if (text2.Contains(HWID))
		{
		}
		else
		{
			Console.ForegroundColor = ConsoleColor.DarkRed;
			Console.WriteLine("LOOKS LIKES U DON'T HAVE ACCESS");
			Console.WriteLine("HERE'S YOUR ACCESS KEY: " + HWID);
			Console.WriteLine("CLICK ENTER TO EXIT");
			Console.ReadLine();
			Environment.Exit(0);
		}
		Console.WriteLine("[WAIT] - PLEASE WAIT WHILE LOADING...");
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Green;
		Thread.Sleep(1000);
		VER = "1.0.1_4";
		LoginMenu();
	}

	public static void SetValues(int ActorIdSet, string TicketSet, string ServerSet)
	{
		ActorId = ActorIdSet;
		Ticket = TicketSet;
		GetServer = ServerSet;
		WebSocketPath = GetWebSocketUrl(ServerSet);
	}

	public static string GetWebSocketUrl(string Server)
	{
		WebClient webClient = new WebClient();
		webClient.Proxy = null;
		return webClient.DownloadString((Server == "US") ? "https://presence-us.mspapis.com/getServer" : "https://presence.mspapis.com/getServer");
	}

	public static void LoginMenu()
	{
		Console.Clear();
		Console.WriteLine("[LOGIN-USERNAME] - Username: ");
		GetUsername = Console.ReadLine();
		Console.Clear();
		Console.WriteLine("[LOGIN-PASSWORD] - Password: ");
		GetPassword = Console.ReadLine();
		Console.Clear();
		Console.WriteLine("[LOGIN-SERVER] - Server: ");
		GetServer = Console.ReadLine().ToUpper();
		Console.Clear();
		Console.WriteLine("[WAIT] - Logging in..");
		Login();
	}

	public static void Login()
	{
		AMFBuilder.GetEndpointForServer(GetServer);
		dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.User.AMFUserServiceWeb.Login", new object[6] { GetUsername, GetPassword, null, null, null, "MSP1-Standalone:XXXXXX" });
		if (val.ToString().Contains("ERROR") || val["loginStatus"]["status"] == "ERROR" || val["loginStatus"]["nebulaLoginStatus"]["status"] == "Error")
		{
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("[LOGIN-ERROR] - Error!");
			Console.ForegroundColor = ConsoleColor.Green;
			Console.WriteLine("[ENTER] - Click Enter to try again");
			Console.ReadLine();
			LoginMenu();
		}
		else if (val["loginStatus"]["status"] == "Success" || val["loginStatus"]["status"] == "ThirdPartyCreated")
		{
			Program.SetValues(val["loginStatus"]["actor"]["ActorId"], val["loginStatus"]["ticket"], GetServer);
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Green;
			Console.WriteLine("[LOGIN-SUCCESS] - Successfuly Logged in!");
			Thread.Sleep(500);
			Menu();
		}
		else
		{
			Console.Clear();
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("[LOGIN-ERROR] - Wrong Username or Password");
			Console.ForegroundColor = ConsoleColor.Green;
			Console.WriteLine("[ENTER] - Click enter for trying again");
			Console.ReadLine();
			LoginMenu();
		}
	}

	public static void LB(string User, string Type)
	{
		if (sessionIdUsed == 15)
		{
			sessionIdUsed = 0;
		}
		dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.User.AMFUserServiceWeb.Login", new object[6]
		{
			User.Split(':')[0],
			User.Split(':')[1],
			null,
			null,
			null,
			"MSP1-Standalone:XXXXXX"
		});
		BotUsername = User.Split(':')[0];
		dynamic val2 = val == null || ((val["loginStatus"]["status"] == "InvalidCredentials") ? true : false);
		if (val2 || false)
		{
			return;
		}
		if (Type == "GrabberForTickets" || Type == "GrabberForTickets2")
		{
			if (val.ToString().Contains("ERROR") || val["loginStatus"]["status"] == "ERROR" || val["loginStatus"]["nebulaLoginStatus"]["status"] == "Error")
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("[LOGIN-ERROR] - Error - " + BotUsername);
				Console.WriteLine("[IP] - Please Change your IP!\n");
				Console.ReadLine();
				LB(User, Type);
			}
			else if (val["loginStatus"]["status"] == "Success" || val["loginStatus"]["status"] == "ThirdPartyCreated")
			{
				Console.ForegroundColor = ConsoleColor.Green;
				Console.WriteLine("[LOGIN-SUCCESS] - Successfuly Logged in - " + BotUsername);
				BotsLogged++;
				Console.Title = "⛤ \ud835\ude40\ud835\ude69\ud835\ude5a\ud835\ude67\ud835\ude63\ud835\ude56\ud835\ude61 | Bots, Grabbed : '" + BotsLogged + "/" + Bots.Length + "'";
				string text = (string)val["loginStatus"]["ticket"];
				string text2 = (string)val["loginStatus"]["nebulaLoginStatus"]["profileId"];
				string text3 = (string)val["loginStatus"]["nebulaLoginStatus"]["accessToken"];
				if (Type == "GrabberForTickets2")
				{
					(string, string, string, string) item = (BotUsername, text, text3, text2);
					BotList.Add(item);
					CS_CDA(text2, text3, text);
				}
				else
				{
					CS_G(BotUsername, text, text2, text3);
				}
			}
			else if (val["loginStatus"]["status"] == "InvalidCredentials" || val["loginStatus"]["nebulaLoginStatus"]["errorDescription"] == "invalid_username_or_password")
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("[LOGIN-ERROR] - Wrong Password - " + BotUsername + "\n");
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("[LOGIN-ERROR] - Error LOGIN-STATUS: " + val["loginStatus"]["status"] + " - " + BotUsername + "\n");
			}
		}
		sessionIdUsed++;
	}

	public static void Menu()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("- MADE BY STZA \n[1] - Get Tickets! \n[2] - Movie Menu! \n- MADE BY STZA  \n");
		Console.WriteLine("[CHOICE] - What do you wanna do?: ");
		switch (Console.ReadLine())
		{
		case "?":
			TutorialMenu();
			break;
		case "1":
			GetTicketsMenu();
			break;
		case "2":
			MoviesMenu();
			break;
		case "3":
			BotAutographsMenu();
			break;
		default:
			Menu();
			break;
		}
	}

	public static void TutorialMenu()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("What Is Leaf?\n");
		Console.WriteLine("Eternal Is MovieTool That Allows You To Earn A Lot Of Starcoins & Fame!");
		Console.WriteLine("Eternal Is Using 8x Stare Method In Movies, So 1 View = 8 Views To Fame Magazine!");
		Console.WriteLine("To Use It Correctly, Login To Tool On Alt (MultiAccount) To Get 8x! \n");
		Console.WriteLine("How To Use Eternal?\n");
		Console.WriteLine("1. First Generate Some Tickets From Option Number 1, First Load Bots From Txt File Name \nThen Write Name Of Txt File You'd Like To Export Tickets (DO NOT CREATE NEW FILE! FILE WILL BE CREATED BY TOOL). \n");
		Console.WriteLine("2. After Generating Tickets You Can Use Rest of The Options \nAll You Have To Do Is Write Txt File Name With Exported Tickets. \n(For Example If You Exported To Lol.txt, When It Asks For Tickets-Exported Write Lol.txt).");
		Console.WriteLine("\n[ENTER] - CLICK ENTER TO EXIT TUTORIAL!");
		Console.ReadLine();
		Menu();
	}

	public static void GetTicketsMenu()
	{
		Console.Clear();
		Console.WriteLine("[BOTS] - Bot txt File: ");
		Bots = File.ReadAllLines(Console.ReadLine());
		Console.Clear();
		Console.WriteLine("[SAVE-PATH] - Ticket txt File: ");
		Path = Console.ReadLine();
		Console.Clear();
		BotsLogged = 0;
		string[] bots = Bots;
		string[] array = bots;
		foreach (object obj in array)
		{
			LB(obj.ToString(), "GrabberForTickets");
		}
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("[SUCCESS] - Successfuly Grabbed Ticket!");
		Console.WriteLine("[ENTER] - Click Enter to Exit!");
		Console.ReadLine();
		Menu();
	}

	public static void MoviesMenu()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("[!] - BACK! \n \n- MADE BY STZA  \n[1] - Movie Tool! \n[2] - Delete Privat Movies! \n");
		Console.WriteLine("[CHOICE] - What do you wanna do??: ");
		switch (Console.ReadLine())
		{
		case "!":
			Menu();
			break;
		case "1":
			AutoGrabbingAndWatchingMenu();
			break;
		case "2":
			CreateMovieAndBotItMenu();
			break;
		case "3":
			BotMovieByIdMenu();
			break;
		case "4":
			DeleteMoviesMenu();
			break;
		default:
			MoviesMenu();
			break;
		}
	}

	public static void CreateMovieAndBotItMenu()
	{
		Console.Clear();
		Console.WriteLine("[AUTOMATED] - AUTOMATED MODE? (Y/N)");
		string text = Console.ReadLine().ToLower();
		if (text == "y")
		{
			IsAutomated = 1;
		}
		else if (text == "n")
		{
			IsAutomated = 0;
		}
		else
		{
			CreateMovieAndBotItMenu();
		}
		if (IsAutomated == 1)
		{
			AutomatedMenu();
		}
		else if (IsAutomated == 0)
		{
			CreateMovieAndBotItAssetMenu();
		}
		else
		{
			CreateMovieAndBotItMenu();
		}
	}

	public static void CreateMovieAndBotItAssetMenu()
	{
		Console.Clear();
		Console.WriteLine("[TICKETS] - TICKETS EXPORTED: ");
		Tickets = File.ReadAllLines(Console.ReadLine());
		BotList.Clear();
		for (int i = 0; i < Tickets.Length; i++)
		{
			(string, string, string, string) item = (Tickets[i].Split('⛤')[0], Tickets[i].Split('⛤')[1], Tickets[i].Split('⛤')[2], Tickets[i].Split('⛤')[3]);
			BotList.Add(item);
		}
		Console.Clear();
		CreateMovie();
		Console.ForegroundColor = ConsoleColor.White;
		Parallel.ForEach<(string, string, string, string)>(BotList, delegate((string Username, string Ticket, string NebulaToken, string NebulaProfile) Bot)
		{
			try
			{
				(BotUsername, _, _, _) = Bot;
				CS_WM(Bot.NebulaProfile, Bot.NebulaToken, Bot.Ticket);
			}
			catch
			{
			}
		});
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("\n[SUCCESS] - SUCCESSFULLY WATCHED YOUR MOVIE!");
		Console.WriteLine("[ENTER] - CLICK ENTER TO EXIT THIS MENU!");
		Console.ReadLine();
		Menu();
	}

	public static void BotMovieByIdMenu()
	{
		Console.Clear();
		Console.WriteLine("[TICKETS] - Tickets txt File: ");
		Tickets = File.ReadAllLines(Console.ReadLine());
		BotList.Clear();
		for (int i = 0; i < Tickets.Length; i++)
		{
			(string, string, string, string) item = (Tickets[i].Split('⛤')[0], Tickets[i].Split('⛤')[1], Tickets[i].Split('⛤')[2], Tickets[i].Split('⛤')[3]);
			BotList.Add(item);
		}
		Console.Clear();
		dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.MovieService.AMFMovieService.GetMovieListForActor", new object[5]
		{
			new TicketHeader
			{
				Ticket = TicketGenerator.HeaderTicket(Ticket)
			},
			Convert.ToInt32(Ticket.Split(',')[1]),
			1,
			0,
			10000
		});
		int num = val["totalRecords"];
		if (num == 0)
		{
			Console.WriteLine("[IDS] - You dont have any Movies");
		}
		else
		{
			for (int j = 0; j < num; j++)
			{
				Console.WriteLine("[MOVIE-NAME] : " + val["list"][j]["name"] + "\n[MOVIE-ID] : " + val["list"][j]["movieId"] + "\n");
			}
		}
		Console.WriteLine("[MOVIE-ID] - Movie ID: ");
		MovieId = Convert.ToInt32(Console.ReadLine());
		MovieIdSecured = MovieId * 10;
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.White;
		Parallel.ForEach<(string, string, string, string)>(BotList, delegate((string Username, string Ticket, string NebulaToken, string NebulaProfile) Bot)
		{
			try
			{
				(BotUsername, _, _, _) = Bot;
				CS_WM(Bot.NebulaProfile, Bot.NebulaToken, Bot.Ticket);
			}
			catch
			{
			}
		});
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("\n[SUCCESS] - Successfuly Watched Movie!");
		Console.WriteLine("[ENTER] - Click Enter to Exit the Menu!");
		Console.ReadLine();
		Menu();
	}

	public static void AutomatedMenu()
	{
		Console.Clear();
		Console.WriteLine("[TICKETS] - TICKETS EXPORTED: ");
		Tickets = File.ReadAllLines(Console.ReadLine());
		BotList.Clear();
		for (int i = 0; i < Tickets.Length; i++)
		{
			(string, string, string, string) item = (Tickets[i].Split('⛤')[0], Tickets[i].Split('⛤')[1], Tickets[i].Split('⛤')[2], Tickets[i].Split('⛤')[3]);
			BotList.Add(item);
		}
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.White;
		sessionIdUsed = 0;
		int num = 0;
		int num2 = 999999;
		while (num < num2)
		{
			CreateMovieAutomated();
			if (sessionIdUsed == 10)
			{
				sessionIdUsed = 0;
			}
			Parallel.ForEach<(string, string, string, string)>(BotList, delegate((string Username, string Ticket, string NebulaToken, string NebulaProfile) Bot)
			{
				try
				{
					(BotUsername, _, _, _) = Bot;
					CS_WM(Bot.NebulaProfile, Bot.NebulaToken, Bot.Ticket);
				}
				catch
				{
				}
			});
			sessionIdUsed++;
		}
		Console.ForegroundColor = ConsoleColor.White;
		Console.WriteLine("\n[SUCCESS] - SUCCESSFULLY WATCHED YOUR MOVIE!");
		Console.WriteLine("[ENTER] - CLICK ENTER TO EXIT THIS MENU!");
		Console.ReadLine();
		Menu();
	}

	public static void AutoGrabbingAndWatchingMenu()
	{
		Console.Clear();
		Console.WriteLine("[BOTS] - BOTS TXT FILENAME: ");
		string path = Console.ReadLine();
		Bots = File.ReadAllLines(path);
		Tickets = File.ReadAllLines(path);
		BotList.Clear();
		BotsLogged = 0;
		Console.Clear();
		sessionIdUsed = 0;
		IsAutomated = 1;
		string[] bots = Bots;
		string[] array = bots;
		foreach (object obj in array)
		{
			LB(obj.ToString(), "GrabberForTickets2");
		}
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.White;
		int num = 0;
		int num2 = 999999;
		while (num < num2)
		{
			for (int i = 0; i < 200; i++)
			{
				CreateMovieAutomated();
				if (sessionIdUsed == 10)
				{
					sessionIdUsed = 0;
				}
				Parallel.ForEach<(string, string, string, string)>(BotList, delegate((string Username, string Ticket, string NebulaToken, string NebulaProfile) Bot)
				{
					try
					{
						(BotUsername, _, _, _) = Bot;
						CS_WM(Bot.NebulaProfile, Bot.NebulaToken, Bot.Ticket);
					}
					catch
					{
					}
				});
				sessionIdUsed++;
			}
			BotList.Clear();
			BotsLogged = 0;
			Console.Clear();
			sessionIdUsed = 0;
			string[] bots2 = Bots;
			string[] array2 = bots2;
			foreach (object obj2 in array2)
			{
				LB(obj2.ToString(), "GrabberForTickets2");
			}
			sessionIdUsed = 0;
		}
		Console.ForegroundColor = ConsoleColor.Green;
		Console.WriteLine("\n[SUCCESS] - SUCCESSFULLY WATCHED YOUR MOVIE!");
		Console.WriteLine("[ENTER] - CLICK ENTER TO EXIT THIS MENU!");
		Console.ReadLine();
		Menu();
	}

	public static void DeleteMoviesMenu()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.White;
		dynamic GetMovieListForActor = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.MovieService.AMFMovieService.GetMovieListForActor", new object[5]
		{
			new TicketHeader
			{
				Ticket = TicketGenerator.HeaderTicket(Ticket)
			},
			Convert.ToInt32(Ticket.Split(',')[1]),
			1,
			0,
			10000
		});
		int num = GetMovieListForActor["totalRecords"];
		Console.Clear();
		Console.WriteLine("[HOW-MUCH] - How many Movies you wanna Delete?: ");
		Console.WriteLine("[HINT] - You have: " + num + " Movies.");
		Console.WriteLine("");
		Console.WriteLine("[CHOICE] - How much you wanna delete?: ");
		int toExclusive = Convert.ToInt32(Console.ReadLine());
		Console.WriteLine();
		Parallel.For(0, toExclusive, delegate(int I2)
		{
			int num2 = GetMovieListForActor["list"][I2]["movieId"];
			object obj = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.MovieService.AMFMovieService.DeleteMovie", new object[3]
			{
				new TicketHeader
				{
					Ticket = TicketGenerator.HeaderTicket(Ticket)
				},
				num2,
				Convert.ToInt32(Ticket.Split(',')[1])
			});
			Console.ForegroundColor = ConsoleColor.White;
			Console.WriteLine("[MOVIE-DELETED] - Successfuly Deleted Movie: " + num2);
		});
		Console.ForegroundColor = ConsoleColor.White;
		Console.WriteLine("\n[SUCCESS] - Successfuly Delete your Movies!");
		Console.WriteLine("[ENTER] - Click Enter to Exit the Menu!");
		Console.ReadLine();
		Menu();
	}

	public static void BotAutographsMenu()
	{
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.White;
		Console.WriteLine("[TICKETS] - TICKETS EXPORTED: ");
		Tickets = File.ReadAllLines(Console.ReadLine());
		BotList.Clear();
		for (int i = 0; i < Tickets.Length; i++)
		{
			(string, string, string, string) item = (Tickets[i].Split('⛤')[0], Tickets[i].Split('⛤')[1], Tickets[i].Split('⛤')[2], Tickets[i].Split('⛤')[3]);
			BotList.Add(item);
		}
		AutographsGiven = 0;
		Console.Clear();
		Console.ForegroundColor = ConsoleColor.White;
		Parallel.ForEach<(string, string, string, string)>(BotList, delegate((string Username, string Ticket, string NebulaToken, string NebulaProfile) Bot)
		{
			try
			{
				(BotUsername, _, _, _) = Bot;
				CS_GA(Bot.NebulaProfile, Bot.NebulaToken, Bot.Ticket);
			}
			catch
			{
			}
		});
		Console.ForegroundColor = ConsoleColor.White;
		Console.WriteLine("\n[SUCCESS] - SUCCESSFULLY GAVE AN AUTOGRAPHS!");
		Console.WriteLine("[ENTER] - CLICK ENTER TO EXIT THIS MENU!");
		Console.ReadLine();
		Menu();
	}

	public static void CreateMovie()
	{
		MovieViews = 0;
		GetMyRoleSecured = Convert.ToInt32(83803589);
		MS.Clear();
		int i = 0;
		for (int num = 8; i < num; i++)
		{
			MS.Add(GetMyRoleSecured / 10);
		}
		WebClient webClient = new WebClient();
		webClient.Proxy = null;
		string text = "1";
		if (text == "1")
		{
			string text2 = GenerateRandomName(12);
			string text3 = HashingUtils.CreateMd5HashUtf8("ETER-" + text2 + "-RNAL").ToUpper();
			byte[] array = webClient.DownloadData("http://eternal.ct8.pl/img/eternal_00050.png");
			byte[] array2 = webClient.DownloadData("https://snapshots.mspcdns.com/v1/snapshots/MSP_PL_blob_moviedata_0_33_314_273");
			byte[] array3 = webClient.DownloadData("https://snapshots.mspcdns.com/v1/snapshots/MSP_PL_blob_movieactorclothesdata_0_33_314_273");
			dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.MobileServices.AMFMovieService.CreateMovieWithSnapshot", new object[9]
			{
				new TicketHeader
				{
					Ticket = TicketGenerator.HeaderTicket(Ticket)
				},
				text3,
				false,
				new Random().Next(29999, 217330),
				array3,
				array2,
				MS.ToArray(),
				array,
				array
			});
            if (val == null)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... \n");
                CreateMovie();
            }
            else if (val.ToString().Contains("ERROR"))
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... \n");
                Thread.Sleep(10000);
                CreateMovie();
            }
            else if (val["movieId"] > -1)
            {
                MovieId = val["movieId"];
                MovieViews = 0;
                StarcoinsEarned = 0;
                MovieIdSecured = MovieId * 10;
                Console.Title = "⛤LeaF  | Current Role : '" + Utils.Username + "', Current Movie : '" + MovieId + "', Views : '" + MovieViews + "/" + Tickets.Length + "' StarCoins : '" + StarcoinsEarned + "'";
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("[MOVIE-SUCCESS] - SUCCESSFULLY CREATED MOVIE! \n");
            }
            else if (val["movieId"] == -1)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... TRYING AGAIN...\n");
                Thread.Sleep(10000);
                val();
            }
            else
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... \n");
                Menu();
            }
        }
    }

    public static void CreateMovieAutomated()
	{
		MovieViews = 0;
		GetMyRoleSecured = Convert.ToInt32(83803589);
		MS.Clear();
		int i = 0;
		for (int num = 8; i < num; i++)
		{
			MS.Add(GetMyRoleSecured / 10);
		}
		WebClient webClient = new WebClient();
		webClient.Proxy = null;
		string text = "1";
		if (text == "1")
		{
			string text2 = GenerateRandomName(12);
			string text3 = HashingUtils.CreateMd5HashUtf8("ETER-" + text2 + "-RNAL").ToUpper();
			byte[] array = webClient.DownloadData("http://eternal.ct8.pl/img/eternal_00050.png");
			byte[] array2 = webClient.DownloadData("https://snapshots.mspcdns.com/v1/snapshots/MSP_PL_blob_moviedata_0_33_314_273");
			byte[] array3 = webClient.DownloadData("https://snapshots.mspcdns.com/v1/snapshots/MSP_PL_blob_movieactorclothesdata_0_33_314_273");
			dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.MobileServices.AMFMovieService.CreateMovieWithSnapshot", new object[9]
			{
				new TicketHeader
				{
					Ticket = TicketGenerator.HeaderTicket(Ticket)
				},
				text3,
				false,
				new Random().Next(29999, 217330),
				array3,
				array2,
				MS.ToArray(),
				array,
				array
			});
			Console.Clear();
			if (val == null)
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... \n");
				CreateMovieAutomated();
			}
			else if (val.ToString().Contains("ERROR"))
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... \n");
				Thread.Sleep(10000);
				CreateMovieAutomated();
			}
			else if (val["movieId"] == -1)
			{
				MovieId = val["movieId"];
				MovieViews = 0;
				StarcoinsEarned = 0;
				MovieIdSecured = MovieId * 10;
				AutomatedStep++;
				Console.Title = "⛤ \ud835\ude40\ud835\ude69\ud835\ude5a\ud835\ude67\ud835\ude63\ud835\ude56\ud835\ude61 | Current Role : '" + Utils.Username + "', Current Movie : '" + MovieId + "', AutomatedStep : '" + AutomatedStep + "', Views : '" + MovieViews + "/" + Tickets.Length + "' StarCoins : '" + StarcoinsEarned + "'";
				Console.ForegroundColor = ConsoleColor.Green;
				Console.WriteLine("[MOVIE-SUCCESS] - SUCCESSFULLY CREATED MOVIE! \n");
			}
			else if (val["movieId"] == -1)
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... TRYING AGAIN...\n");
				Thread.Sleep(5000);
				CreateMovieAutomated();
			}
			else
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("\n[MOVIE-ERROR] - AN ERROR OCCURRED WHILE CREATING MOVIE... \n");
				Menu();
			}
		}
	}

	public static void CDA(string Ticket)
	{
		dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.Awarding.AMFAwardingService.claimDailyAward", new object[4]
		{
			new TicketHeader
			{
				Ticket = TicketGenerator.HeaderTicket(Ticket)
			},
			"wheel",
			120,
			Convert.ToInt32(Ticket.Split(',')[1])
		});
		try
		{
			if (val["description"] == "RateLimited" || val["description"] == "RateLimit")
			{
				Console.ForegroundColor = ConsoleColor.Red;
				Console.WriteLine("[IP] - PLEASE CHANGE YOUR IP ADDRESS AND THEN CLICK ENTER TO CONTINUE! \n");
				Console.ReadLine();
				CDA(Ticket);
			}
		}
		catch (Exception)
		{
		}
		if ((!((val == null) ? true : false) || 1 == 0) && (!(val.ToString().Contains("ERROR") ? true : false) || 1 == 0))
		{
			if (val["amount"] == 120)
			{
				Console.ForegroundColor = ConsoleColor.Green;
				Console.WriteLine("[CLAIM-SUCCESS] - SUCCESSFULLY CLAIMED DAILY AWARD! - " + BotUsername + "\n");
				return;
			}
		}
		else
		{
        }
        if (val.ToString().Contains("ERROR"))
		{
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("[IP] - PLEASE CHANGE YOUR IP ADDRESS AND THEN CLICK ENTER TO CONTINUE! \n");
			Console.ReadLine();
			CDA(Ticket);
		}
		else if (val["amount"] != 120)
		{
			Console.ForegroundColor = ConsoleColor.White;
			Console.WriteLine("[CLAIM-NEUTRAL] - USER IS ALREADY VERIFIED! - " + BotUsername + "\n");
		}
		else
		{
			Console.ForegroundColor = ConsoleColor.Red;
			Console.WriteLine("[CLAIM-ERROR] - AN ERROR OCCURRED! - " + BotUsername + "\n");
		}
	}

	public static void WM(string Ticket)
	{
		dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.MobileServices.AMFMovieService.MovieWatched", new object[2]
		{
			new TicketHeader
			{
				Ticket = TicketGenerator.HeaderTicket(Ticket)
			},
			MovieIdSecured / 10
		});
		if ((!((val == null) ? true : false) || 1 == 0) && (!(val.ToString().Contains("ERROR") ? true : false) || 1 == 0))
		{
			if (val["awardedFame"] > 10 && val["returnType"] == 2)
			{
				MovieViews++;
				StarcoinsEarned = MovieViews * 25;
				if (IsAutomated == 1)
				{
					Console.Title = "⛤ \ud835\ude40\ud835\ude69\ud835\ude5a\ud835\ude67\ud835\ude63\ud835\ude56\ud835\ude61 | Current Role : '" + Utils.Username + "', Current Movie : '" + MovieId + "', AutomatedStep : '" + AutomatedStep + "', Views : '" + MovieViews + "/" + Tickets.Length + "' StarCoins : '" + StarcoinsEarned + "'";
				}
				else
				{
					Console.Title = "⛤ \ud835\ude40\ud835\ude69\ud835\ude5a\ud835\ude67\ud835\ude63\ud835\ude56\ud835\ude61 | Current Role : '" + Utils.Username + "', Current Movie : '" + MovieId + "', Views : '" + MovieViews + "/" + Tickets.Length + "' StarCoins : '" + StarcoinsEarned + "'";
				}
				Console.ForegroundColor = ConsoleColor.White;
				Console.WriteLine("[WATCH-SUCCESS] - SUCCESSFULLY WATCHED MOVIE! - " + BotUsername);
				return;
			}
		}
		else
		{
			bool flag = false;
		}
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine("[WATCH-ERROR] - AN ERROR OCCURRED WHILE WATCHING MOVIE! - " + BotUsername);
	}

	public static void GA(string Ticket)
	{
		dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.UserSession.AMFUserSessionService.GiveAutographAndCalculateTimestamp", new object[3]
		{
			new TicketHeader
			{
				Ticket = TicketGenerator.HeaderTicket(Ticket)
			},
			Convert.ToInt32(Ticket.Split(',')[1]),
			ActorId
		});
		if ((!((val == null) ? true : false) || 1 == 0) && (!(val.ToString().Contains("ERROR") ? true : false) || 1 == 0))
		{
			if (val["Fame"] > 20 || val["Fame"] == 20)
			{
				AutographsGiven++;
				Console.Title = "⛤ \ud835\ude40\ud835\ude69\ud835\ude5a\ud835\ude67\ud835\ude63\ud835\ude56\ud835\ude61 | Autographs, Sent : '" + AutographsGiven + "/" + Tickets.Length + "'";
				Console.ForegroundColor = ConsoleColor.White;
				Console.WriteLine("[AUTO-SUCCESS] - SUCCESSFULLY GAVE AN AUTOGRAPH! - " + BotUsername);
				return;
			}
		}
		else
		{
			bool flag = false;
		}
		Console.ForegroundColor = ConsoleColor.Red;
		Console.WriteLine("[AUTO-ERROR] - AN ERROR OCCURRED WHILE GIVING AN AUTOGRAPH! - " + BotUsername);
	}

	public static void CS_G(string Name, string Ticket, string NebulaProfile, string NebulaToken)
	{
		string item = Name + "⛤" + Ticket + "⛤" + NebulaToken + "⛤" + NebulaProfile;
		CS_CDA(NebulaProfile, NebulaToken, Ticket);
		try
		{
			BotExport.Add(item);
			File.WriteAllLines(Path, BotExport);
		}
		catch (Exception)
		{
		}
	}

	public static void CS_CDA(string NebulaProfile, string NebulaToken, string Ticket)
	{
		try
		{
			using WebSocket val = new WebSocket("ws://" + WebSocketPath.Replace('-', '.') + ":10843/" + WebSocketPath.Replace('.', '-') + "/?transport=websocket");
			val.Connect();
			val.Send("42[\"10\",{\"messageType\":10,\"messageContent\":{\"version\":3,\"applicationId\":\"APPLICATION_WEB\",\"country\":\"" + GetServer + "\",\"username\":\"" + NebulaProfile + "\",\"access_token\":\"" + NebulaToken + "\"}}]");
			Thread.Sleep(200);
			CDA(Ticket);
		}
		catch (Exception)
		{
		}
	}

	public static void CS_WM(string NebulaProfile, string NebulaToken, string Ticket)
	{
		try
		{
			using WebSocket val = new WebSocket("ws://" + WebSocketPath.Replace('-', '.') + ":10843/" + WebSocketPath.Replace('.', '-') + "/?transport=websocket");
			val.Connect();
			val.Send("42[\"10\",{\"messageType\":10,\"messageContent\":{\"version\":3,\"applicationId\":\"APPLICATION_WEB\",\"country\":\"" + GetServer + "\",\"username\":\"" + NebulaProfile + "\",\"access_token\":\"" + NebulaToken + "\"}}]");
			Thread.Sleep(200);
			WM(Ticket);
		}
		catch (Exception)
		{
		}
	}

	public static void CS_GA(string NebulaProfile, string NebulaToken, string Ticket)
	{
		try
		{
			using WebSocket val = new WebSocket("ws://" + WebSocketPath.Replace('-', '.') + ":10843/" + WebSocketPath.Replace('.', '-') + "/?transport=websocket");
			val.Connect();
			val.Send("42[\"10\",{\"messageType\":10,\"messageContent\":{\"version\":3,\"applicationId\":\"APPLICATION_WEB\",\"country\":\"" + GetServer + "\",\"username\":\"" + NebulaProfile + "\",\"access_token\":\"" + NebulaToken + "\"}}]");
			Thread.Sleep(200);
			GA(Ticket);
		}
		catch (Exception)
		{
		}
	}
}
