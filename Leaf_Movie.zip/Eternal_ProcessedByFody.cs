internal class Eternal_ProcessedByFody
{
	internal const string FodyVersion = "6.5.5.0";

	internal const string Costura = "5.7.0";
}
