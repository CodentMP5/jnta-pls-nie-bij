using System.Security.Cryptography;
using System.Text;

namespace Eternals.Utils;

internal class HashingUtils
{
	public static string CreateMd5HashUtf8(string Input)
	{
		return CreateMd5Hash(Input, Encoding.UTF8);
	}

	private static string CreateMd5Hash(string input, Encoding encoding)
	{
		MD5 mD = MD5.Create();
		byte[] array = mD.ComputeHash(encoding.GetBytes(input));
		StringBuilder stringBuilder = new StringBuilder();
		for (int i = 0; i < array.Length; i++)
		{
			stringBuilder.Append(array[i].ToString("x2"));
		}
		return stringBuilder.ToString();
	}
}
