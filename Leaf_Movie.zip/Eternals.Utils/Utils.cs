using System;
using Eternal;

namespace Eternals.Utils;

internal class Utils
{
	public static string Username = "NULL";

	public static int GetRole = 1;

	public static object GetMyRole(string HWID)
	{
		Username = "flagrante";
		try
		{
			dynamic val = AMFBuilder.BuildAMF("MovieStarPlanet.WebService.UserSession.AMFUserSessionService.GetActorIdFromName", new object[1] { Username });
			GetRole = Convert.ToInt32(val);
		}
		catch (Exception ex)
		{
			Console.WriteLine("ERROR! " + ex);
			GetMyRole(HWID);
		}
		int num = Convert.ToInt32(GetRole);
		int num2 = num * 10;
		Program.GetMyRole = num;
		return num2;
	}

	public static object ConvertHWIDForEternal(string HWID)
	{
		string text = HWID.Split('-')[4];
		string text2 = HWID.Split('-')[5];
		string text3 = HashingUtils.CreateMd5HashUtf8(text + text2).ToUpper();
		return "ETERNAL," + text3;
	}
}
