using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.IO;
using System.Net;
using System.Text;
using Eternals.Utils;
using FluorineFx.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace Eternals;

public class Session
{
	public static Dictionary<string, string> Refs = new Dictionary<string, string>();

	public static string Server = "";

	public static string Endpoint = "";

	public static string SessionID = "NGEzNzBhYzcyZWIwNWUyODZmMGYyNGNhMzVlY2ViYTQ0NjM3NDdmMzUxMzgzMw==";
    private static string val;

    public static object GetHistogram(string TjData)
	{
		using WebClient webClient = new WebClient();
		NameValueCollection nameValueCollection = new NameValueCollection();
		nameValueCollection["tjdata"] = TjData;
		nameValueCollection["hash"] = HashingUtils.CreateMd5HashUtf8(TjData + "_noHello");
		webClient.Proxy = null;
		JObject val2 = (JObject)JsonConvert.DeserializeObject<JObject>(val);
		return val2["session"]!["histogram"]!.ToString();
	}

	public Session()
	{
		Server = "GB";
		GetEndpointForServer(Server);
	}

	public string GetSessionId()
	{
		dynamic val = BuildAMF("MovieStarPlanet.WebService.Os.AMFOs.CreateOsRef", new object[0]);
		if (val.ToString().Contains("ERROR"))
		{
			try
			{
				if (Server == "GB")
				{
					Server = "FR";
					GetEndpointForServer(Server);
				}
				else if (Server == "FR")
				{
					Server = "GB";
					GetEndpointForServer(Server);
				}
			}
			catch (Exception ex)
			{
				Console.WriteLine("ERROR WHILE TRYING TO CHANGE SERVER! " + ex);
			}
			return GetSessionId();
		}
		string text = GetHistogram(val["TjData"]);
		dynamic val2 = BuildAMF("MovieStarPlanet.WebService.Os.AMFOs.RunOsCheck", new object[2]
		{
			val["RefId"],
			text
		});
		return val2;
	}

	public static void GetEndpointForServer(string Server)
	{
		WebClient webClient = new WebClient();
		webClient.Proxy = null;
		JObject val = JObject.Parse(webClient.DownloadString("https://disco.mspapis.com/disco/v1/services/msp/" + Server + "?services=mspwebservice"));
		Endpoint = (string?)val["Services"]![0]!["Endpoint"];
		webClient.Dispose();
	}

	public static object BuildAMF(string Method, object[] Arguments)
	{
		Random random = new Random();
		string value = random.Next(0, 213) + "." + random.Next(0, 146) + "." + random.Next(0, 50) + "." + random.Next(0, 30);
		AMFMessage val = new AMFMessage(3);
		val.AddHeader(new AMFHeader("sessionID", mustUnderstand: false, SessionID));
		val.AddHeader(new AMFHeader("id", mustUnderstand: false, Checksum.createChecksum(Arguments)));
		val.AddHeader(new AMFHeader("needClassName", mustUnderstand: false, false));
		val.AddBody(new AMFBody(Method, "/1", Arguments));
		MemoryStream memoryStream = new MemoryStream();
		AMFSerializer val2 = new AMFSerializer(memoryStream);
		val2.WriteMessage(val);
		((BinaryWriter)val2).Flush();
		((BinaryWriter)val2).Dispose();
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(Endpoint + "/Gateway.aspx?method=" + Method);
		httpWebRequest.Headers.Add("X-forwarded-for", value);
		httpWebRequest.Referer = "app:/cache/t1.bin/[[DYNAMIC]]/2";
		httpWebRequest.Accept = "text/xml, application/xml, application/xhtml+xml, text/html;q=0.9, text/plain;q=0.8, text/css, image/png, image/jpeg, image/gif;q=0.8, application/x-shockwave-flash, video/mp4;q=0.9, flv-application/octet-stream;q=0.8, video/x-flv;q=0.7, audio/mp4, application/futuresplash, */*;q=0.5, application/x-mpegURL";
		httpWebRequest.ContentType = "application/x-amf";
		httpWebRequest.UserAgent = "Mozilla/5.0 (Windows; U; en) AppleWebKit/533.19.4 (KHTML, like Gecko) AdobeAIR/32.0";
		httpWebRequest.Headers["X-Flash-Version"] = "32,0,0,100";
		httpWebRequest.Method = "POST";
		byte[] bytes = Encoding.Default.GetBytes(Encoding.Default.GetString(memoryStream.ToArray()));
		httpWebRequest.GetRequestStream().Write(bytes, 0, bytes.Length);
		try
		{
			HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			memoryStream = new MemoryStream();
			httpWebResponse.GetResponseStream().CopyTo(memoryStream);
			object result = DecodeAMF(memoryStream.ToArray());
			memoryStream.Dispose();
			httpWebResponse.Dispose();
			return result;
		}
		catch (Exception ex)
		{
			memoryStream.Dispose();
			return "ERROR! " + ex.ToString();
		}
	}

	public static dynamic DecodeAMF(byte[] Body)
	{
		MemoryStream memoryStream = new MemoryStream(Body);
		AMFDeserializer val = new AMFDeserializer(memoryStream);
		AMFMessage val2 = val.ReadAMFMessage();
		object content = val2.Bodies[0].Content;
		memoryStream.Dispose();
		((BinaryReader)val).Dispose();
		return content;
	}
}
