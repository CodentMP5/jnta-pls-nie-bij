namespace Eternals;

internal class TicketHeader
{
	public string Ticket { get; set; }

	public string anyAttribute { get; set; } = null;

}
