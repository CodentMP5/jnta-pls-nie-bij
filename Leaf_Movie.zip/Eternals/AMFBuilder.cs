using System;
using System.IO;
using System.Net;
using System.Text;
using FluorineFx.IO;
using Newtonsoft.Json.Linq;

namespace Eternals;

internal class AMFBuilder
{
	public static string Endpoint = "";

	public static string Session = "MzJkMDdhMDE3OGExNDRiNjQ0YmNjMDNhMzZiN2FkZDk2ZWNjNDJhYzc5YzhhNQ==";

	public static void GetEndpointForServer(string Server)
	{
		WebClient webClient = new WebClient();
		JObject val = JObject.Parse(webClient.DownloadString("https://disco.mspapis.com/disco/v1/services/msp/" + Server.ToLower() + "?services=mspwebservice"));
		Endpoint = (string?)val["Services"]![0]!["Endpoint"];
		webClient.Dispose();
	}

	public static object BuildAMF(string Method, object[] Arguments)
	{
		Random random = new Random();
		string value = random.Next(0, 213) + "." + random.Next(0, 146) + "." + random.Next(0, 50) + "." + random.Next(0, 30);
		AMFMessage val = new AMFMessage(3);
		val.AddHeader(new AMFHeader("sessionID", mustUnderstand: false, Session));
		val.AddHeader(new AMFHeader("id", mustUnderstand: false, Checksum.createChecksum(Arguments)));
		val.AddHeader(new AMFHeader("needClassName", mustUnderstand: false, false));
		val.AddBody(new AMFBody(Method, "/1", Arguments));
		MemoryStream memoryStream = new MemoryStream();
		AMFSerializer val2 = new AMFSerializer(memoryStream);
		val2.WriteMessage(val);
		((BinaryWriter)val2).Flush();
		((BinaryWriter)val2).Dispose();
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(Endpoint + "/Gateway.aspx?method=" + Method);
		httpWebRequest.Headers.Add("X-forwarded-for", value);
		httpWebRequest.Referer = "app:/cache/t1.bin/[[DYNAMIC]]/2";
		httpWebRequest.Accept = "text/xml, application/xml, application/xhtml+xml, text/html;q=0.9, text/plain;q=0.8, text/css, image/png, image/jpeg, image/gif;q=0.8, application/x-shockwave-flash, video/mp4;q=0.9, flv-application/octet-stream;q=0.8, video/x-flv;q=0.7, audio/mp4, application/futuresplash, */*;q=0.5, application/x-mpegURL";
		httpWebRequest.ContentType = "application/x-amf";
		httpWebRequest.UserAgent = "Mozilla/5.0 (Windows; U; en) AppleWebKit/533.19.4 (KHTML, like Gecko) AdobeAIR/32.0";
		httpWebRequest.Headers["X-Flash-Version"] = "32,0,0,100";
		httpWebRequest.Method = "POST";
		byte[] bytes = Encoding.Default.GetBytes(Encoding.Default.GetString(memoryStream.ToArray()));
		httpWebRequest.GetRequestStream().Write(bytes, 0, bytes.Length);
		try
		{
			HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			memoryStream = new MemoryStream();
			httpWebResponse.GetResponseStream().CopyTo(memoryStream);
			object result = DecodeAMF(memoryStream.ToArray());
			memoryStream.Dispose();
			httpWebResponse.Dispose();
			return result;
		}
		catch (Exception ex)
		{
			memoryStream.Dispose();
			return "ERROR! " + ex.ToString();
		}
	}

	public static object BuildProxyAMF(string Method, object[] Arguments, string Proxy)
	{
		Random random = new Random();
		string value = random.Next(0, 213) + "." + random.Next(0, 146) + "." + random.Next(0, 50) + "." + random.Next(0, 30);
		AMFMessage val = new AMFMessage(3);
		val.AddHeader(new AMFHeader("sessionID", mustUnderstand: false, Session));
		val.AddHeader(new AMFHeader("id", mustUnderstand: false, Checksum.createChecksum(Arguments)));
		val.AddHeader(new AMFHeader("needClassName", mustUnderstand: false, false));
		val.AddBody(new AMFBody(Method, "/1", Arguments));
		MemoryStream memoryStream = new MemoryStream();
		AMFSerializer val2 = new AMFSerializer(memoryStream);
		val2.WriteMessage(val);
		((BinaryWriter)val2).Flush();
		((BinaryWriter)val2).Dispose();
		HttpWebRequest httpWebRequest = (HttpWebRequest)WebRequest.Create(Endpoint + "/Gateway.aspx?method=" + Method);
		httpWebRequest.Headers.Add("X-forwarded-for", value);
		httpWebRequest.Proxy = new WebProxy("http://" + Proxy);
		httpWebRequest.Referer = "app:/cache/t1.bin/[[DYNAMIC]]/2";
		httpWebRequest.Accept = "text/xml, application/xml, application/xhtml+xml, text/html;q=0.9, text/plain;q=0.8, text/css, image/png, image/jpeg, image/gif;q=0.8, application/x-shockwave-flash, video/mp4;q=0.9, flv-application/octet-stream;q=0.8, video/x-flv;q=0.7, audio/mp4, application/futuresplash, */*;q=0.5, application/x-mpegURL";
		httpWebRequest.ContentType = "application/x-amf";
		httpWebRequest.UserAgent = "Mozilla/5.0 (Windows; U; en) AppleWebKit/533.19.4 (KHTML, like Gecko) AdobeAIR/32.0";
		httpWebRequest.Headers["X-Flash-Version"] = "32,0,0,100";
		httpWebRequest.Method = "POST";
		byte[] bytes = Encoding.Default.GetBytes(Encoding.Default.GetString(memoryStream.ToArray()));
		try
		{
			httpWebRequest.GetRequestStream().Write(bytes, 0, bytes.Length);
			HttpWebResponse httpWebResponse = (HttpWebResponse)httpWebRequest.GetResponse();
			memoryStream = new MemoryStream();
			httpWebResponse.GetResponseStream().CopyTo(memoryStream);
			object result = DecodeAMF(memoryStream.ToArray());
			memoryStream.Dispose();
			httpWebResponse.Dispose();
			return result;
		}
		catch (Exception ex)
		{
			memoryStream.Dispose();
			return "ERROR! " + ex.ToString();
		}
	}

	public static dynamic DecodeAMF(byte[] Body)
	{
		MemoryStream memoryStream = new MemoryStream(Body);
		AMFDeserializer val = new AMFDeserializer(memoryStream);
		AMFMessage val2 = val.ReadAMFMessage();
		object content = val2.Bodies[0].Content;
		memoryStream.Dispose();
		((BinaryReader)val).Dispose();
		return content;
	}
}
